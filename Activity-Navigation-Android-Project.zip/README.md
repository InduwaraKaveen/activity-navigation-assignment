# Activity Navigation assignment

A minimal Android app with two activities. The button in `MainActivity` opens `SecondActivity` using an explicit Intent.

## Open and run

1. Open this `activity-navigation` folder in Android Studio.
2. Let Gradle sync, then run the `app` configuration on an emulator or Android device.
3. Tap **Second Activity** to navigate. Use the system Back action to return.

## How it works

- `MainActivity` loads `activity_main.xml` in `onCreate`.
- `findViewById` retrieves the button by its XML ID.
- `setOnClickListener` registers code that runs when the user taps the button.
- The explicit `Intent(this, SecondActivity::class.java)` names the destination activity.
- `startActivity(intent)` asks Android to launch that activity.
- The manifest declares both activities. `MainActivity` has the launcher intent filter; `SecondActivity` is internal to this app.
- Android creates the destination and calls its `onCreate`, which displays `activity_second.xml`.

## GitHub submission

Create a private GitHub repository, push this project, and add the lecturer's GitHub account as a collaborator. Put the repository URL in the Excel submission sheet. A private repository URL alone does not grant access.
