# Activity Navigation

A small Android app that demonstrates moving from one activity to another.

## Activities

- `MainActivity` displays a button labelled **Second Activity**.
- `SecondActivity` is the screen opened by that button.

## Button click and Intent

`MainActivity` sets a click listener on the button. When tapped, the listener creates an explicit `Intent` for `SecondActivity` and calls `startActivity()` to open it. The app manifest declares both activities and sets `MainActivity` as the launcher screen.

## Run the app

Open the project folder in Android Studio, allow Gradle to sync, and run the app on an emulator or Android device. Tap **Second Activity** to open the second screen. Use Back to return to the main screen.
